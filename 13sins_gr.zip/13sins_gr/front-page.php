<?php get_header(); ?>
<div class="wrapper">
    <div class="container-fluid">
        <div class="row">

            <div class="col-md-1"></div>
            <div class="col-md-3">
                <div id="menus">
                    <canvas id="menu-highlight" width="800" height="600"></canvas>

                    <a href="https://online-pdd-kchr.ru/смотреть/">
                        <div class="italic highlight" onmouseover="highlight(this, event)">
                            Смотреть

                        </div>
                    </a>

                    <div class="italic" onmouseover="highlight(this, event)">
                        Играть
                    </div>
                    <div class="normal">
                        О НАС
                    </div>
                    <div class="normal">
                        ПРАВИЛА
                    </div>
                    <div class="normal">
                        ТАБЛИЦА ЛИДЕРОВ
                    </div>
                    <div class="normal" data-toggle="modal" data-target="#regModal">
                        ВХОД / РЕГИСТРАЦИЯ
                    </div>
                </div>
            </div>
            <div class="col-md-7 text_center">
                <p>&nbsp;</p>
                <p>&nbsp;</p>
                <iframe title="Casscage's player frame" i18n-title="channel#ShareDialog:playerEmbedFrame|Embed player Frame copied from share dialog" allowfullscreen="true" src="https://mixer.com/embed/player/Casscage?disableLowLatency=1" width="620" height="349"> </iframe>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>
