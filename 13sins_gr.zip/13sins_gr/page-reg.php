<?php get_header(); ?>
<div class="wrapper">
    <div class="container-fluid">
        <div class="row">

            <style>
                .content h2 {
                    color: #6c60ff;
                    text-transform: uppercase;
                    font-family: overwatch;
                    font-size: 48px;
                    margin-top: 20px;
                }

                .content {
                    background-color: #f7f7f7;
                    border-radius: 10px;
                    margin-top: 20px;
                    margin-bottom: 20px;
                    padding: 30px;
                    padding-bottom: 40px;
                    min-height: 80vh;
                }

                .kama_breadcrumbs {
                    margin-bottom: 20px;
                }

            </style>

            <div class="col-md-1"></div>
            <div class="col-md-10 content">
                <h2>Регистрация</h2>
                <div class="row">
                    <div class="col-md-4">
                        <!-- Registration -->
                        <div id="register-form">
                            <div class="title">
                                <span>Присоединяйся к нам в мир развлечений!</span>
                            </div>
                            <hr>
                            <form action="<?php echo site_url('wp-login.php?action=register', 'login_post') ?>" method="post">
                                <input type="text" name="user_login" placeholder="Логин" id="user_login" class="form-control" /> <br>
                                <input type="text" name="user_email" placeholder="Почта" id="user_email" class="form-control" /> <br>
                                <?php do_action('register_form'); ?>
                                <input type="submit" class="btn btn-primary" value="Зарегистрироваться" id="register" />
                                <hr />
                                <p class="statement">Пароль будет отправлен вам на почту.</p>

                            </form>
                        </div>
                    </div><!-- /Registration -->
                    <div class="col-md-8"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>
