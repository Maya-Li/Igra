<?php if( is_front_page() ) : ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php wp_title('«', true, 'right'); ?> <?php bloginfo('name'); ?></title>
    <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
    <meta http-equiv="Content-type" content="text/html; charset=<?php bloginfo('charset'); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link href='https://fonts.googleapis.com/css?family=Varela' rel='stylesheet' type='text/css'>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" integrity="sha256-h20CPZ0QyXlBuAw7A+KluUYx/3pK+c7lYEpqLTlxjYQ=" crossorigin="anonymous" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

    <style>
        body {
            width: 100vw;
            background-color: black;
            background-image: url(<?php echo get_template_directory_uri();
            ?>/images/bg.jpg);
            background-size: contain;
            background-position: center;
            background-repeat: no-repeat;
        }

        /*nav*/
        @font-face {
            font-family: overwatch;
            src: url(https://us.battle.net/forums/static/fonts/f014015d/f014015d.woff);
        }

        @font-face {
            font-family: overwatch-italic;
            src: url(https://us.battle.net/forums/static/fonts/bignoodletoo/bignoodletoo.woff);
        }

        * {
            cursor: url(https://cdn.discordapp.com/attachments/303406782104207362/315839175406649345/Overwatch.cur), auto;
            -moz-user-select: -moz-none;
            -ms-user-select: none;
            -webkit-user-select: none;
            user-select: none;
        }

        html,
        body,
        #main {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
        }

        #main {
            background-size: 100% 100%;
            background-repeat: no-repeat;
        }

        #left {
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            width: 500px;
            height: 100%;
        }

        #logo {
            position: relative;
            padding: 7px 0 0 30px;
            opacity: 0.9;
        }

        #logo img {
            width: 390px;
        }

        #logo #version {
            position: absolute;
            bottom: 6px;
            color: rgba(255, 255, 255, 0.7);
            font-family: overwatch;
        }

        #menus {
            position: relative;
            height: 500px;
            margin-top: 50px;
            padding-left: 35px;
        }

        #menus .italic {
            position: relative;
            left: 0;
            font-family: overwatch-italic;
            font-size: 63px;
            color: #fff;
            text-shadow: 0px 0px 3px #cecece;
            transform-origin: bottom;
            transition: all .05s ease-in;
        }

        #menus .italic.highlight {
            color: #f3c026;
            text-shadow: 0px 0px 5px #bb7e29;
        }

        #menus .italic:hover {
            left: 20px;
            transform: scaleY(1.05);
        }

        #menus .normal {
            position: relative;
            left: 0;
            line-height: 1.7;
            font-family: overwatch;
            font-size: 24px;
            color: #e3f2ff;
            text-shadow: 0 0 2px #336cec;
            transform-origin: bottom;
            transition: all .05s ease-in;
        }

        #menus .normal:hover {
            left: 6px;
            transform: scaleY(1.1);
            color: #fff;
        }

        #menu-highlight {
            position: absolute;
            left: 0;
            top: 0;
        }

        #chat {
            position: relative;
            flex: 1;
        }

        #chat #chat-log {
            display: flex;
            flex-direction: column-reverse;
            background: transparent;
            height: 54px;
            margin-bottom: 48px;
            position: absolute;
            left: 35px;
            width: 274px;
            bottom: 30px;
            font-family: overwatch;
            padding: 0 5px;
            color: rgba(255, 255, 255, 0.8);
            overflow-x: hidden;
            border: 2px solid rgba(255, 255, 255, 0);
            transition: all .1s ease-out, background .1s ease-out .2s;
            border-radius: 2px;
            text-shadow: 1px 1px 0px rgba(0, 0, 0, 0.5);
        }

        #chat #chat-log.active {
            background: rgba(0, 0, 0, 0.6);
            height: calc(100% - 85px);
            transition: all .1s ease-out;
        }

        #chat #chat-input {
            display: flex;
            width: 146px;
            opacity: 0;
            position: absolute;
            left: 35px;
            bottom: 30px;
            font-family: overwatch;
            background: rgba(0, 0, 0, 0.6);
            padding: 10px;
            color: rgba(255, 255, 255, 0.8);
            border: 2px solid rgba(255, 255, 255, 0);
            transition: all .1s ease-out;
            border-radius: 2px;
        }

        #chat #chat-input #text {
            background: transparent;
            border: 0;
            outline: 0 !important;
            color: #fff;
            padding-left: 5px;
            flex: 1;
        }

        #chat #chat-input.active {
            opacity: 1;
            width: 264px;
        }

        #chat #enter {
            display: inline-block;
            z-index: 1;
            position: absolute;
            left: 35px;
            bottom: 31px;
            font-family: overwatch;
            background: rgba(0, 0, 0, 0.2);
            padding: 10px;
            color: rgba(255, 255, 255, 0.5);
            border: 2px solid rgba(255, 255, 255, 0.1);
        }

        #player {
            display: flex;
            height: 60px;
            position: fixed;
            right: 25px;
            top: 25px;
        }

        #info {
            display: flex;
            background: rgba(0, 0, 0, 0.5);
            margin-left: 6px;
            align-items: center;
        }

        #info img {
            width: 57px;
            height: 60px;
            border-left: 5px solid #b1fb23;
        }

        #info #name {
            color: rgba(255, 255, 255, 0.9);
            margin-left: 14px;
            font-size: 18px;
            font-family: Arial;
        }

        #info #rank {
            color: #fff;
            background: #a56a54;
            padding: 0 6px;
            margin-left: 6px;
            margin-right: 57px;
            margin-bottom: 8px;
            border-radius: 3px;
            font-size: 13px;
            font-family: overwatch;
        }

        #hero {
            position: fixed;
            bottom: 21%;
            right: 53px;
            text-align: right;
        }

        #hero #hero-name {
            font-family: overwatch-italic;
            font-size: 86px;
            color: #fff;
            line-height: 1;
            text-shadow: 0 -2px 1px rgba(255, 255, 255, 0.8);
        }

        #hero #hero-unlocks {
            font-family: overwatch;
            line-height: 1;
            font-size: 22px;
            color: rgba(255, 255, 255, 0.85);
            text-shadow: 0 0 2px black;
        }

        #hero #hero-unlocks span {
            color: #fff;
        }

        video#bgvid {
            position: fixed;
            top: 50%;
            left: 50%;
            min-width: 100%;
            min-height: 100%;
            width: auto;
            height: auto;
            z-index: -100;
            -ms-transform: translateX(-50%) translateY(-50%);
            -moz-transform: translateX(-50%) translateY(-50%);
            -webkit-transform: translateX(-50%) translateY(-50%);
            transform: translateX(-50%) translateY(-50%);
            background: #000;
            background-size: cover;
        }

        ::-webkit-scrollbar {
            display: none;
        }

        ::-webkit-scrollbar-button {
            display: none;
        }

        ::-webkit-scrollbar-track {
            display: none;
        }

        ::-webkit-scrollbar-track-piece {
            display: none;
        }

        ::-webkit-scrollbar-thumb {
            display: none;
        }

        ::-webkit-scrollbar-corner {
            display: none;
        }

        ::-webkit-resizer {
            display: none;
        }

        /*nav*/
        .header {
            font-family: overwatch;
            color: #bfbfbf;
            position: relative;
            top: -15px;
            font-size: 14px;
        }

        /*logo*/
        .glitch {
            font-family: overwatch-italic;
            color: #ecffe4;
            font-size: 80px;
            position: relative;
            width: 400px;
        }

        @keyframes noise-anim {
            0% {
                clip: rect(99px, 9999px, 17px, 0);
            }

            5% {
                clip: rect(71px, 9999px, 64px, 0);
            }

            10% {
                clip: rect(54px, 9999px, 89px, 0);
            }

            15% {
                clip: rect(47px, 9999px, 14px, 0);
            }

            20% {
                clip: rect(19px, 9999px, 13px, 0);
            }

            25% {
                clip: rect(8px, 9999px, 95px, 0);
            }

            30% {
                clip: rect(49px, 9999px, 70px, 0);
            }

            35% {
                clip: rect(96px, 9999px, 81px, 0);
            }

            40% {
                clip: rect(34px, 9999px, 59px, 0);
            }

            45% {
                clip: rect(2px, 9999px, 69px, 0);
            }

            50% {
                clip: rect(72px, 9999px, 50px, 0);
            }

            55% {
                clip: rect(40px, 9999px, 31px, 0);
            }

            60% {
                clip: rect(84px, 9999px, 44px, 0);
            }

            65% {
                clip: rect(92px, 9999px, 91px, 0);
            }

            70% {
                clip: rect(3px, 9999px, 62px, 0);
            }

            75% {
                clip: rect(56px, 9999px, 93px, 0);
            }

            80% {
                clip: rect(81px, 9999px, 100px, 0);
            }

            85% {
                clip: rect(28px, 9999px, 70px, 0);
            }

            90% {
                clip: rect(84px, 9999px, 98px, 0);
            }

            95% {
                clip: rect(1px, 9999px, 32px, 0);
            }

            100% {
                clip: rect(18px, 9999px, 37px, 0);
            }
        }

        .glitch:after {
            content: attr(data-text);
            position: absolute;
            left: 2px;
            text-shadow: -1px 0 red;
            top: 0;
            color: white;
            background: black;
            overflow: hidden;
            clip: rect(0, 900px, 0, 0);
            animation: noise-anim 2s infinite linear alternate-reverse;
        }

        @keyframes noise-anim-2 {
            0% {
                clip: rect(11px, 9999px, 54px, 0);
            }

            5% {
                clip: rect(81px, 9999px, 47px, 0);
            }

            10% {
                clip: rect(11px, 9999px, 68px, 0);
            }

            15% {
                clip: rect(89px, 9999px, 43px, 0);
            }

            20% {
                clip: rect(23px, 9999px, 82px, 0);
            }

            25% {
                clip: rect(15px, 9999px, 59px, 0);
            }

            30% {
                clip: rect(37px, 9999px, 42px, 0);
            }

            35% {
                clip: rect(43px, 9999px, 52px, 0);
            }

            40% {
                clip: rect(47px, 9999px, 39px, 0);
            }

            45% {
                clip: rect(73px, 9999px, 39px, 0);
            }

            50% {
                clip: rect(98px, 9999px, 67px, 0);
            }

            55% {
                clip: rect(75px, 9999px, 11px, 0);
            }

            60% {
                clip: rect(35px, 9999px, 31px, 0);
            }

            65% {
                clip: rect(57px, 9999px, 90px, 0);
            }

            70% {
                clip: rect(90px, 9999px, 2px, 0);
            }

            75% {
                clip: rect(65px, 9999px, 94px, 0);
            }

            80% {
                clip: rect(55px, 9999px, 54px, 0);
            }

            85% {
                clip: rect(99px, 9999px, 61px, 0);
            }

            90% {
                clip: rect(76px, 9999px, 41px, 0);
            }

            95% {
                clip: rect(21px, 9999px, 14px, 0);
            }

            100% {
                clip: rect(83px, 9999px, 95px, 0);
            }
        }

        .glitch:before {
            content: attr(data-text);
            position: absolute;
            left: -2px;
            text-shadow: 1px 0 blue;
            top: 0;
            color: white;
            background: black;
            overflow: hidden;
            clip: rect(0, 900px, 0, 0);
            animation: noise-anim-2 3s infinite linear alternate-reverse;
        }

        /*logo*/
        .text_right {
            text-align: right;
        }

        .hor_info {
            padding-top: 20px;
        }

        .hor_info li {
            font-family: overwatch-italic;
            font-size: 30px;
            display: inline-block;
            margin-right: 20px;
            color: white;
        }

        .hor_info li a {
            color: white;
        }

        .price_pool {
            color: #c7cd2b;
        }

        .reg_pool {
            color: #08ae08;
        }

        .text_center {
            text-align: center;
        }

        .logo_glitch:hover {
            text-decoration: none;
        }

    </style>
    <!-- Modal -->
    <div class="modal fade" id="regModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Вход</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form name="loginform" id="loginform" action="<?php bloginfo('url') ?>/wp-login.php" method="post">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Логин</label>
                            <input type="text" class="form-control" name="log" id="user_login" aria-describedby="emailHelp">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Пароль</label>
                            <input type="password" class="form-control" name="pwd" id="user_pass">
                        </div>
                        <div class="form-group form-check">
                            <input type="checkbox" class="form-check-input" id="exampleCheck1">
                            <label class="form-check-label" for="exampleCheck1">Запомнить меня</label>
                        </div>
                        <button type="submit" class="btn btn-primary" name="wp-submit" id="wp-submit" value="Войти">Войти</button> &nbsp;&nbsp; <a href="https://online-pdd-kchr.ru/reg/">Регистрация</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <nav class="nav">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-1"></div>
                <div class="col-6 col-md-5">
                    <a href="index.php" class="logo_glitch">
                        <div class="glitch" data-text="13ГРЕХОВ">13ГРЕХОВ</div>
                    </a>
                    <h2 class="header">Игра которой управляете вы</h2>
                </div>
                <div class="col-6 col-md-5 text_right">
                    <ul class="hor_info">
                        <li>
                            <img src="<?php echo get_template_directory_uri(); ?>/images/image.png" width="24px" alt="">
                            <span class="price_pool"> 200 000 RUB</span>
                        </li>
                        <li>
                            <img src="<?php echo get_template_directory_uri() ?>/images/image2.png" width="30px" alt="">
                            <span class="reg_pool"> 200 000 ЗАРЕГИСТРИРОВАНО</span>
                        </li>
                        <li>
                           <?php
                                if ( is_user_logged_in() ) {
                                    ?>
                                    <a href="#"><?php $current_user = wp_get_current_user(); echo $current_user->user_login ?></a>    
                            <?php
                                }else{ ?>
                                    <a href="#" data-toggle="modal" data-target="#regModal">ВХОД / РЕГИСТРАЦИЯ</a>
                            <?php        
                                }
                            ?>
                            
                        </li>
                    </ul>
                </div>
                <div class="col-12 col-md-1"></div>
            </div>
        </div>
    </nav>
    <?php else : ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <title><?php wp_title('«', true, 'right'); ?> <?php bloginfo('name'); ?></title>
        <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
        <meta http-equiv="Content-type" content="text/html; charset=<?php bloginfo('charset'); ?>">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link href='https://fonts.googleapis.com/css?family=Varela' rel='stylesheet' type='text/css'>
        <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" integrity="sha256-h20CPZ0QyXlBuAw7A+KluUYx/3pK+c7lYEpqLTlxjYQ=" crossorigin="anonymous" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php wp_head(); ?>
    </head>

    <body <?php body_class(); ?>>

        <style>
            body {
                width: 100vw;
                background-color: black;
                background-image: url(<?php echo get_template_directory_uri();
                ?>/images/bg.jpg);
                background-size: contain;
                background-position: center;
                background-repeat: no-repeat;
            }

            /*nav*/
            @font-face {
                font-family: overwatch;
                src: url(https://us.battle.net/forums/static/fonts/f014015d/f014015d.woff);
            }

            @font-face {
                font-family: overwatch-italic;
                src: url(https://us.battle.net/forums/static/fonts/bignoodletoo/bignoodletoo.woff);
            }

            * {
                cursor: url(https://cdn.discordapp.com/attachments/303406782104207362/315839175406649345/Overwatch.cur), auto;
                -moz-user-select: -moz-none;
                -ms-user-select: none;
                -webkit-user-select: none;
                user-select: none;
            }

            html,
            body,
            #main {
                width: 100%;
                height: 100%;
                margin: 0;
                padding: 0;
            }

            #main {
                background-size: 100% 100%;
                background-repeat: no-repeat;
            }

            #left {
                position: relative;
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                width: 500px;
                height: 100%;
            }

            #logo {
                position: relative;
                padding: 7px 0 0 30px;
                opacity: 0.9;
            }

            #logo img {
                width: 390px;
            }

            #logo #version {
                position: absolute;
                bottom: 6px;
                color: rgba(255, 255, 255, 0.7);
                font-family: overwatch;
            }

            #menus {
                position: relative;
                height: 500px;
                margin-top: 50px;
                padding-left: 35px;
            }

            #menus .italic {
                position: relative;
                left: 0;
                font-family: overwatch-italic;
                font-size: 63px;
                color: #fff;
                text-shadow: 0px 0px 3px #cecece;
                transform-origin: bottom;
                transition: all .05s ease-in;
            }

            #menus .italic.highlight {
                color: #f3c026;
                text-shadow: 0px 0px 5px #bb7e29;
            }

            #menus .italic:hover {
                left: 20px;
                transform: scaleY(1.05);
            }

            #menus .normal {
                position: relative;
                left: 0;
                line-height: 1.7;
                font-family: overwatch;
                font-size: 24px;
                color: #e3f2ff;
                text-shadow: 0 0 2px #336cec;
                transform-origin: bottom;
                transition: all .05s ease-in;
            }

            #menus .normal:hover {
                left: 6px;
                transform: scaleY(1.1);
                color: #fff;
            }

            #menu-highlight {
                position: absolute;
                left: 0;
                top: 0;
            }

            #chat {
                position: relative;
                flex: 1;
            }

            #chat #chat-log {
                display: flex;
                flex-direction: column-reverse;
                background: transparent;
                height: 54px;
                margin-bottom: 48px;
                position: absolute;
                left: 35px;
                width: 274px;
                bottom: 30px;
                font-family: overwatch;
                padding: 0 5px;
                color: rgba(255, 255, 255, 0.8);
                overflow-x: hidden;
                border: 2px solid rgba(255, 255, 255, 0);
                transition: all .1s ease-out, background .1s ease-out .2s;
                border-radius: 2px;
                text-shadow: 1px 1px 0px rgba(0, 0, 0, 0.5);
            }

            #chat #chat-log.active {
                background: rgba(0, 0, 0, 0.6);
                height: calc(100% - 85px);
                transition: all .1s ease-out;
            }

            #chat #chat-input {
                display: flex;
                width: 146px;
                opacity: 0;
                position: absolute;
                left: 35px;
                bottom: 30px;
                font-family: overwatch;
                background: rgba(0, 0, 0, 0.6);
                padding: 10px;
                color: rgba(255, 255, 255, 0.8);
                border: 2px solid rgba(255, 255, 255, 0);
                transition: all .1s ease-out;
                border-radius: 2px;
            }

            #chat #chat-input #text {
                background: transparent;
                border: 0;
                outline: 0 !important;
                color: #fff;
                padding-left: 5px;
                flex: 1;
            }

            #chat #chat-input.active {
                opacity: 1;
                width: 264px;
            }

            #chat #enter {
                display: inline-block;
                z-index: 1;
                position: absolute;
                left: 35px;
                bottom: 31px;
                font-family: overwatch;
                background: rgba(0, 0, 0, 0.2);
                padding: 10px;
                color: rgba(255, 255, 255, 0.5);
                border: 2px solid rgba(255, 255, 255, 0.1);
            }

            #player {
                display: flex;
                height: 60px;
                position: fixed;
                right: 25px;
                top: 25px;
            }

            #info {
                display: flex;
                background: rgba(0, 0, 0, 0.5);
                margin-left: 6px;
                align-items: center;
            }

            #info img {
                width: 57px;
                height: 60px;
                border-left: 5px solid #b1fb23;
            }

            #info #name {
                color: rgba(255, 255, 255, 0.9);
                margin-left: 14px;
                font-size: 18px;
                font-family: Arial;
            }

            #info #rank {
                color: #fff;
                background: #a56a54;
                padding: 0 6px;
                margin-left: 6px;
                margin-right: 57px;
                margin-bottom: 8px;
                border-radius: 3px;
                font-size: 13px;
                font-family: overwatch;
            }

            #hero {
                position: fixed;
                bottom: 21%;
                right: 53px;
                text-align: right;
            }

            #hero #hero-name {
                font-family: overwatch-italic;
                font-size: 86px;
                color: #fff;
                line-height: 1;
                text-shadow: 0 -2px 1px rgba(255, 255, 255, 0.8);
            }

            #hero #hero-unlocks {
                font-family: overwatch;
                line-height: 1;
                font-size: 22px;
                color: rgba(255, 255, 255, 0.85);
                text-shadow: 0 0 2px black;
            }

            #hero #hero-unlocks span {
                color: #fff;
            }

            video#bgvid {
                position: fixed;
                top: 50%;
                left: 50%;
                min-width: 100%;
                min-height: 100%;
                width: auto;
                height: auto;
                z-index: -100;
                -ms-transform: translateX(-50%) translateY(-50%);
                -moz-transform: translateX(-50%) translateY(-50%);
                -webkit-transform: translateX(-50%) translateY(-50%);
                transform: translateX(-50%) translateY(-50%);
                background: #000;
                background-size: cover;
            }

            ::-webkit-scrollbar {
                display: none;
            }

            ::-webkit-scrollbar-button {
                display: none;
            }

            ::-webkit-scrollbar-track {
                display: none;
            }

            ::-webkit-scrollbar-track-piece {
                display: none;
            }

            ::-webkit-scrollbar-thumb {
                display: none;
            }

            ::-webkit-scrollbar-corner {
                display: none;
            }

            ::-webkit-resizer {
                display: none;
            }

            /*nav*/
            .header {
                font-family: overwatch;
                color: #bfbfbf;
                position: relative;
                top: -15px;
                font-size: 14px;
            }

            /*logo*/
            .glitch {
                font-family: overwatch-italic;
                color: #ecffe4;
                font-size: 80px;
                position: relative;
                width: 400px;
            }

            @keyframes noise-anim {
                0% {
                    clip: rect(99px, 9999px, 17px, 0);
                }

                5% {
                    clip: rect(71px, 9999px, 64px, 0);
                }

                10% {
                    clip: rect(54px, 9999px, 89px, 0);
                }

                15% {
                    clip: rect(47px, 9999px, 14px, 0);
                }

                20% {
                    clip: rect(19px, 9999px, 13px, 0);
                }

                25% {
                    clip: rect(8px, 9999px, 95px, 0);
                }

                30% {
                    clip: rect(49px, 9999px, 70px, 0);
                }

                35% {
                    clip: rect(96px, 9999px, 81px, 0);
                }

                40% {
                    clip: rect(34px, 9999px, 59px, 0);
                }

                45% {
                    clip: rect(2px, 9999px, 69px, 0);
                }

                50% {
                    clip: rect(72px, 9999px, 50px, 0);
                }

                55% {
                    clip: rect(40px, 9999px, 31px, 0);
                }

                60% {
                    clip: rect(84px, 9999px, 44px, 0);
                }

                65% {
                    clip: rect(92px, 9999px, 91px, 0);
                }

                70% {
                    clip: rect(3px, 9999px, 62px, 0);
                }

                75% {
                    clip: rect(56px, 9999px, 93px, 0);
                }

                80% {
                    clip: rect(81px, 9999px, 100px, 0);
                }

                85% {
                    clip: rect(28px, 9999px, 70px, 0);
                }

                90% {
                    clip: rect(84px, 9999px, 98px, 0);
                }

                95% {
                    clip: rect(1px, 9999px, 32px, 0);
                }

                100% {
                    clip: rect(18px, 9999px, 37px, 0);
                }
            }

            .glitch:after {
                content: attr(data-text);
                position: absolute;
                left: 2px;
                text-shadow: -1px 0 red;
                top: 0;
                color: white;
                background: black;
                overflow: hidden;
                clip: rect(0, 900px, 0, 0);
                animation: noise-anim 2s infinite linear alternate-reverse;
            }

            @keyframes noise-anim-2 {
                0% {
                    clip: rect(11px, 9999px, 54px, 0);
                }

                5% {
                    clip: rect(81px, 9999px, 47px, 0);
                }

                10% {
                    clip: rect(11px, 9999px, 68px, 0);
                }

                15% {
                    clip: rect(89px, 9999px, 43px, 0);
                }

                20% {
                    clip: rect(23px, 9999px, 82px, 0);
                }

                25% {
                    clip: rect(15px, 9999px, 59px, 0);
                }

                30% {
                    clip: rect(37px, 9999px, 42px, 0);
                }

                35% {
                    clip: rect(43px, 9999px, 52px, 0);
                }

                40% {
                    clip: rect(47px, 9999px, 39px, 0);
                }

                45% {
                    clip: rect(73px, 9999px, 39px, 0);
                }

                50% {
                    clip: rect(98px, 9999px, 67px, 0);
                }

                55% {
                    clip: rect(75px, 9999px, 11px, 0);
                }

                60% {
                    clip: rect(35px, 9999px, 31px, 0);
                }

                65% {
                    clip: rect(57px, 9999px, 90px, 0);
                }

                70% {
                    clip: rect(90px, 9999px, 2px, 0);
                }

                75% {
                    clip: rect(65px, 9999px, 94px, 0);
                }

                80% {
                    clip: rect(55px, 9999px, 54px, 0);
                }

                85% {
                    clip: rect(99px, 9999px, 61px, 0);
                }

                90% {
                    clip: rect(76px, 9999px, 41px, 0);
                }

                95% {
                    clip: rect(21px, 9999px, 14px, 0);
                }

                100% {
                    clip: rect(83px, 9999px, 95px, 0);
                }
            }

            .glitch:before {
                content: attr(data-text);
                position: absolute;
                left: -2px;
                text-shadow: 1px 0 blue;
                top: 0;
                color: white;
                background: black;
                overflow: hidden;
                clip: rect(0, 900px, 0, 0);
                animation: noise-anim-2 3s infinite linear alternate-reverse;
            }

            /*logo*/
            .text_right {
                text-align: right;
            }

            .hor_info {
                padding-top: 20px;
            }

            .hor_info li {
                font-family: overwatch-italic;
                font-size: 24px;
                display: inline-block;
                margin-right: 20px;
                color: white;
            }

            .hor_info li a {
                color: white;
            }

            .price_pool {
                color: #c7cd2b;
            }

            .reg_pool {
                color: #08ae08;
            }

            .text_center {
                text-align: center;
            }

            .logo_glitch:hover {
                text-decoration: none;
            }

        </style>
        <!-- Modal -->
        <div class="modal fade" id="regModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Вход</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form name="loginform" id="loginform" action="<?php bloginfo('url') ?>/wp-login.php" method="post">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Логин</label>
                                <input type="text" class="form-control" name="log" id="user_login" aria-describedby="emailHelp">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Пароль</label>
                                <input type="password" class="form-control" name="pwd" id="user_pass">
                            </div>
                            <div class="form-group form-check">
                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                <label class="form-check-label" for="exampleCheck1">Запомнить меня</label>
                            </div>
                            <button type="submit" class="btn btn-primary" name="wp-submit" id="wp-submit" value="Войти">Войти</button> &nbsp;&nbsp; <a href="https://online-pdd-kchr.ru/reg/">Регистрация</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <nav class="nav">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-3">
                        <a href="/index.php" class="logo_glitch">
                            <div class="glitch" data-text="13ГРЕХОВ">13ГРЕХОВ</div>
                        </a>
                    </div>
                    <div class="col-12 col-md-7">
                        <ul class="hor_info text_right">
                            <li><a class="nav-link active" href="#">Смотреть</a></li>
                            <li><a class="nav-link" href="#">Играть</a></li>
                            <li><a class="nav-link" href="#">О нас</a></li>
                            <li><a class="nav-link" href="#">Правила</a></li>
                            <li><a class="nav-link" href="#">Таблица лидеров</a></li>
                            <li><a class="nav-link" href="#" data-toggle="modal" data-target="#regModal">Вход / Регистрация</a></li>
                        </ul>
                    </div>
                    <div class="col-12 col-md-1"></div>
                </div>
            </div>
        </nav>
        <?php endif; ?>
