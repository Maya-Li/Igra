    <style>
        .footer {
            background-color: #161616;
            color: white;
            padding-top: 50px;
            padding-bottom: 20px;

        }

        .footer li a {
            color: grey;
        }

        .footer li {
            list-style-type: none;
        }

        .footer ul {
            padding-left: 0;
            margin-left: 0;
        }

    </style>

    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-3">
                    <h5>Меню</h5>
                    <ul>
                        <li>
                            <a href="#">Смотреть</a>
                        </li>
                        <li>
                            <a href="#">Играть</a>
                        </li>
                        <li>
                            <a href="#">Правила</a>
                        </li>
                        <li>
                            <a href="#">О нас</a>
                        </li>
                        <li>
                            <a href="#" data-toggle="modal" data-target="#regModal">Вход / Регистрация</a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-3"></div>
                <div class="col-md-4">
                    <h5>Напишите нам</h5>
                    <ul>
                        <li>
                            <a href="#">Тех поддержка</a>
                        </li>
                        <li>
                            <a href="#">Контакты</a>
                        </li>
                    </ul>
                    <h5>Мы в соц сетях:</h5>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-1">

                </div>
                <div class="col-md-10">
                    Все права защищены 13Грехов 2020(с)
                </div>
                <div class="col-md-1"></div>
            </div>
        </div>
    </footer>
    <?php wp_footer(); ?>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>

    <script>
        //nav
        var canvas = document.getElementById('menu-highlight');
        var ctx = canvas.getContext('2d');
        var start = new Date().getTime() - 5000;
        var gradients = [-1];
        var offsetTop = -100;
        var isHighlightActive = false;
        var theme = new Audio('/');
        theme.volume = 0.1;

        theme.play();

        var Particle = function() {
            this.radius = (Math.random() * 1) + 0.5;
            this.top = (Math.random() * 20) - 20;
            this.left = Math.random() * 100;
            this.speed = 1 / this.radius;
            this.opacity = 1;
            this.disintegrateRate = (Math.random() * 0.005) + 0.001;
        }

        var particles = [];

        for (var i = 0; i < 10; i++) {
            particles.push(new Particle());
        }

        function drawHiglight() {
            /* rect */
            var currentTime = new Date().getTime();
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            var grH = ctx.createLinearGradient(0, 0, 600, 0);

            if (currentTime - start > 5000 && gradients[0] < 0.1) {
                start = new Date().getTime();
                gradients = [1, 1, 0.9, 0.7, 0.6, 0.5, 0.5, 0.4, 0.3, 0];
            }

            for (var i = 0; i < gradients.length; i++) {
                grH.addColorStop('0.' + i, 'rgba(255,255,255,' + gradients[i] + ')');

                if (gradients[i] > 0.1) {
                    gradients[i] -= 0.01;
                }
            }

            ctx.fillStyle = grH;
            ctx.fillRect(0, offsetTop, 600, 10);
            /* end of rect */

            /* particles */
            for (var i = 0; i < particles.length; i++) {
                ctx.beginPath();
                ctx.arc(particles[i].left, offsetTop + 15 + particles[i].top, particles[i].radius, 0, 2 * Math.PI);
                ctx.closePath();
                ctx.fillStyle = 'rgba(255,255,255,' + particles[i].opacity + ')';
                ctx.fill();

                particles[i].left += particles[i].speed;
                particles[i].opacity -= particles[i].disintegrateRate;

                if (particles[i].opacity < 0 || particles[i].left > 700) {
                    particles[i] = new Particle();
                }
            }
            /* end of particles */

            if (isHighlightActive === true) {
                requestAnimationFrame(drawHiglight);
            }
        }


        function highlight(element, event) {
            event.stopImmediatePropagation();
            offsetTop = element.offsetTop + 25;
            start = new Date().getTime();
            gradients = [1, 1, 0.9, 0.7, 0.6, 0.5, 0.5, 0.4, 0.3, 0];

            if (isHighlightActive === false) {
                isHighlightActive = true;
                requestAnimationFrame(drawHiglight);
            }
        }

        document.getElementById('main').onmouseover = function() {
            if (offsetTop !== -100) offsetTop = -100;
            isHighlightActive = false;
        }

        var isChatActive = false;
        var chatInput = document.getElementById('text');
        var chatLog = document.getElementById('chat-log');

        document.body.onkeydown = function(event) {
            if (event.keyCode === 13 && isChatActive === false) {
                isChatActive = true;
                document.getElementById('enter').style.display = 'none';
                document.getElementById('chat-log').classList.add('active');
                document.getElementById('chat-input').classList.add('active');
                chatInput.focus();
            } else if (event.keyCode === 13 && isChatActive === true) {
                if (chatInput.value === 'no u') {
                    var message = document.createElement('div');
                    message.innerHTML = '[SureFourteen]: ' + chatInput.value;
                    chatLog.prepend(message);
                    var message = document.createElement('div');
                    message.style.color = 'rgb(255, 66, 66)';
                    message.innerHTML = '[Genji]: Understandable, have a nice day';
                    chatLog.prepend(message);
                } else if (chatInput.value !== '') {
                    var message = document.createElement('div');
                    message.innerHTML = '[SureFourteen]: ' + chatInput.value;
                    chatLog.prepend(message);
                }

                isChatActive = false;
                chatInput.value = '';
                document.getElementById('enter').style.display = 'flex';
                chatLog.classList.remove('active');
                document.getElementById('chat-input').classList.remove('active');
            }
        }

        document.body.focus();
        //nav

    </script>
    </body>

    </html>
