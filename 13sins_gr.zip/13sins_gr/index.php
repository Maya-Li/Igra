<?php get_header(); ?>
<div class="wrapper">
    <div class="container-fluid">
        <div class="row">
            
            <style>
                .content h2{
                    color: #6c60ff;
                    text-transform: uppercase;
                    font-family: overwatch;
                    font-size: 48px;
                    margin-top: 20px;
                }
                .content{
                    background-color: #f7f7f7;
                    border-radius: 10px;
                    margin-top: 20px;
                    margin-bottom: 20px;
                    padding: 30px;
                    padding-bottom: 40px;
                    min-height: 80vh;
                }
                .kama_breadcrumbs{
                    margin-bottom: 20px;
                }
            </style>
            
            <div class="col-md-1"></div>
            <div class="col-md-10 content">
                <h2><?php the_title(); ?></h2>
                <?php if( function_exists('kama_breadcrumbs') ) kama_breadcrumbs(); ?>
                <?php if (have_posts()): while (have_posts()): the_post(); ?>
                <?php the_content(); ?>
                <?php endwhile; endif; ?>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>
